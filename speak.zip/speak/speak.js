function positive(){
    const word = "Un";
    document.getElementById("word").value = word + document.getElementById("word").value;
}
function negative(){
    const word = "ul";
    document.getElementById("word").value = document.getElementById("word").value + word;
}
function neutral(){
    const word = "all";
    document.getElementById("word").value = document.getElementById("word").value + word;
}