
var flag = true;

function create(event){
    if(flag === true){
        var place=document.getElementById("place").value;
        var c=2;
        var r;
        if(place==="chennai")
        {
            r=10;
        }
        else if(place==="coimbatore")
        {
            r=8;
        }
        else if(place==="salem")
        {
            r=7;
        }
        else if(place==="trichy")
        {
            r=7;
        }
        else{
            r=6;
        }
        for(let i=0;i<r;i++)
        {   var input = document.createElement("tr");
            document.getElementById("mytable").appendChild(input)

            for(let j = 0; j<c; j++){
            var inp = document.createElement("input");
            document.getElementById("mytable").appendChild(inp)
            }
        }
        event.preventDefault();
        flag = false
    }
    
}