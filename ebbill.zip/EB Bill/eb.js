function bill()
{
    var unit=document.getElementById("units").value;
    document.getElementById("consume").value=unit;
    var charge;
    if(unit<=100){
        charge=unit*3;
    document.getElementById("charges").value=charge;
    }
    else {
        charge = unit * 3.5;
        document.getElementById("charges").value = charge.toString();
    }
    document.getElementById("totalcharge").value=charge;
    var f=150;
    document.getElementById("fixed").value=f;
    var s=50;
    document.getElementById("subsidy").value=s;
    var ns=50;
    document.getElementById("nsubsidy").value=ns;
    document.getElementById("total").value=charge+f-s-ns;
}