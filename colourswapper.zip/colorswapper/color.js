const boxes = document.querySelectorAll("div[id^='box']");
      
        boxes.forEach((box, index) => {
          box.addEventListener("click", () => {
            box.style.display = "none";
            if (index < boxes.length - 1) {
              boxes[index + 1].style.display = "block";
            } else {
              boxes[0].style.display = "block";
            }
          });
        });