function create()
{
    let note=20;
    let pencil=30;
    let Pen=25;
    let scale=10;
    let book=50;
    var n=document.getElementById("note").value;
    var p=document.getElementById("pencil").value;
    var pe=document.getElementById("pen").value;
    var s=document.getElementById("scale").value;
    var b=document.getElementById("book").value;
    var a=note-n;
    var b=pencil-p;
    var c=Pen-pe;
    var d=scale-s;
    var e=book-b;
    if(a===20 && b===30 && c===25 && d===10 && e===50)
    {
        var bill=window.open("",">Bill","width=400,height=400");
        bill.document.write("<h1>Enter the value:</h1>");
    }
    else{
    var bill=window.open("",">Bill","width=400,height=400");
    bill.document.write("<h1>Remaining Stock</h1>"+
                        "<p>Note: "+a+"</p>"+
                        "<p>Pencil:"+b+"</p>"+
                        "<p>Pen:"+c+"</p>"+
                        "<p>Scale:"+d+"</p>"+
                        "<p>Book:"+e+"</p>"
                        );
    }

}





    // var bill=window.open("",">Bill", "width=400,height=400");
    // bill.document.write(" <hi>Grocery bill</h1>"+
    //                         "<p>Name:"+name+"</p>"+
    //                         "<p>Quantity:"+q+"</p>"+
    //                         "<p>Price:"+p+"</p>"+
    //                         "<p>Total Cost:"+total+"</p>"
    //                         );

