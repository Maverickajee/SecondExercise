function bill(event)
{
    var name=document.getElementById("name").value;
    console.log(name);
    var q= document.getElementById("quantity").value;
    var p= document.getElementById("price").value;
    var total;
    total=q*p;
    document.getElementById("total").value=total;
    event.preventDefault();


    var bill=window.open("",">Bill", "width=400,height=400");
    bill.document.write(" <h1>Grocery bill</h1>"+
                            "<p>Name:"+name+"</p>"+
                            "<p>Quantity:"+q+"</p>"+
                            "<p>Price:"+p+"</p>"+
                            "<p>Total Cost:"+total+"</p>"
                            );
}
