function order(event) {
    event.preventDefault();
  
    // Get the selected size
    var size = document.querySelector('input[name="size"]:checked').value;
  
    // Get the selected deep pan option
    var deepPan = document.querySelector('input[name="Deep pan"]:checked');
  
    // Check if deep pan is selected
    if (deepPan) {
      var deepPanOption = deepPan.value;
    } else {
      var deepPanOption = "No";
    }
  
    // Get the selected toppings
    var toppings = document.querySelectorAll('input[name="topping"]:checked');
    var toppingsList = ""; 
    for (var i = 0; i < toppings.length; i++) {
      toppingsList += toppings[i].value + ", ";
    }
    if (toppingsList == "") {
      toppingsList = "No";
    }
  
    // Get the selected delivery option
    var delivery = document.querySelector('input[name="delivery"]:checked');
  
    // Calculate the cost based on the selected options
    var cost = 0;
    switch (size) {
      case "small":
        cost = 50;
        break;
      case "medium":
        cost = 70;
        break;
      case "large":
        cost = 100;
        break;
    }
    if (deepPanOption == "Deep Pan") {
      cost += 20;
    }
    if (toppingsList != "No") {
      cost += (toppings.length * 10);
    }
    if (delivery) {
      cost += 50;
    }
  
    // Open a new page and display the bill on it
    var billWindow = window.open("", ">Bill", "width=400,height=400");
    billWindow.document.write("<h1><u>Pizza Bill</u></h1>" +
                               "<p>Size: " + size + "</p>" +
                               "<p>Deep Pan: " + deepPanOption + "</p>" +
                               "<p>Toppings: " + toppingsList + "</p>" +
                               "<p>Delivery: " + (delivery ? "Yes" : "No") + "</p>" +
                               "<p>Cost: Rs." + cost + "</p>");
  }